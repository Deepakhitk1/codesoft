# CODSOFT_T1
A Landing page using HTML and CSS.
